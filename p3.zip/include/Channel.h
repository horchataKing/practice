#pragma once
#include <string>
#include <vector>
#include "Tokenizer.h"
#include "Keyframe.h"
#include "core.h"
class Channel {
public:
	std::string extra_in, extra_out;
	std::vector<Keyframe*> keys;
	float tangent_start, tangent_end;
	float start_time, end_time, offset,period;

	// ==Variables==
	Channel(Tokenizer &token);
	void InitializeCubics();
	void InitializeTangents();
	float Evaluate(float t);
	~Channel();
};