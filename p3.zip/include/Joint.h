#pragma once
#include <vector>
#include "DOF.h"
#include "Cube.h"
#include "core.h"
#include "Tokenizer.h"
class Joint{
public:
	// ==========Data==========
	glm::mat4 local, world;
	// Num of DOF
	int dofNum;

	// The pose vector will later be modified so that
	// it is better suited to each specific joint type.
	// For now, it is made specifically for balljoints
	std::vector<DOF> pose_vector;
	std::vector<Joint*> children;
	Joint* parent;
	glm::vec3 offset;
	glm::vec3 boxMin;
	glm::vec3 boxMax;
	glm::vec2 rotxlimit;
	glm::vec2 rotylimit;
	glm::vec2 rotzlimit;
	float dofX, dofY, dofZ;
	Cube* box;
	


	// ==========Functions==========
	void Update(glm::mat4* parent);
	bool Load(Tokenizer &token, std::vector<Joint*> *joints);
	void AddChild(Joint* child, std::vector<Joint*>* joints);
	void Draw(const glm::mat4& viewProjMtx, GLuint shader);

	// Constructor
	Joint();
	// Deconstructor
	~Joint();


};