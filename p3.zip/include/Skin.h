#pragma once
#include <vector>
#include "Tokenizer.h"
#include "Vertex.h"
#include "Triangle.h"
//#include "Skeleton.h"
#include "Joint.h"
#include "core.h"
class Skin
{
public:
	// ==========Model Matrix & Color==========
	// Model matrix.
	glm::mat4 model = glm::mat4(1.0f);


	glm::vec3 color = glm::vec3(1.0f, 0.95f, 0.1f);

	// ==========Variables==========
	std::vector<std::vector<float>>skinWeights;
	std::vector<std::vector<GLuint>> joint_indices; // Should be equal in size to skinweights,
								 // meant to store the joint index associated with
								 // the weight
	GLuint VAO, VBO_positions, VBO_normals, EBO;

	//std::vector<Vertex> vertices;
	std::vector<glm::vec3> positions;
	//std::vector<Triangle> triangles;
	std::vector<GLuint> indices;
	std::vector<glm::vec3> normals;
	std::vector<glm::mat4> bindings;
	std::vector<glm::mat4> invertedB;
	// ==========Functions==========
	
	bool Load(Tokenizer& token);
	void Update(std::vector<Joint*> *jointsVec);
	void Draw(const glm::mat4& viewProjMtx, GLuint shader);
	void GeometryLoad();
	Skin(Tokenizer& token);
	~Skin();
};