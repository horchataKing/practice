#pragma once
class DOF{
public:
	float value, min, max, original_val;
public:
	DOF();
	void SetValue(float v);
	void SetOriginal(float v);
	void ResetDOF();
	float GetValue();
	void SetMinMax(float inMin, float inMax);
};