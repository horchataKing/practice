#pragma once
#include "core.h"
#include "Skeleton.h"
#include "Animation.h"
#include <ctime>
class AnimationPlayer {
public:
	float time, prevTime;
	Animation* animation;
	Skeleton* skel;
	AnimationPlayer(Skeleton* s);
	~AnimationPlayer();
	void Load(char* file);
	void Update();

};
