#pragma once
#include <vector>
#include "Channel.h"
#include "Tokenizer.h"
#include "Skeleton.h"
#include "core.h"

class Animation {
public:
	float start_time, end_time;
	std::vector<Channel*> channels;

	// ===Functions===
	Animation(Tokenizer &token);
	void InitializeChannels();
	void Update(float t, glm::mat4& T, Skeleton* skel);
	~Animation();
};