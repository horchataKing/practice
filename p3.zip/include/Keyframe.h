#pragma once
#include "core.h"
#include <string>
class Keyframe {
public:

	float deltaT;
	float time;
	float value;
	float tangent_in,tangent_out;
	std::string  rule_in;
	std::string  rule_out;

	// Cubic coefficients
	float A, B, C, D;

	// Functions
	Keyframe(float t, float v, std::string in, std::string out);
	float Evaluate(float t);
};