#pragma once
class Vertex
{
public:
	float x, y, z;
	Vertex(float x, float y, float z);
};