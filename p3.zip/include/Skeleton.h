#pragma once
#include "core.h"
#include "Joint.h"
#include "Skin.h"
class Skeleton
{
public:
	// ======Data======
	Joint* root;
	Skin* skin;
	std::vector<Joint*> joints;
	// ======Functions======
	bool Load(const char *skelFile, const char* skinFile);
	void Update();
	void Update(glm::mat4& T);
	void Draw(const glm::mat4& viewProjMtx, GLuint shader);
	Skeleton();
	~Skeleton();
};