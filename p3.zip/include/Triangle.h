#include "Vertex.h"
#include "core.h"
#pragma once

class Triangle
{
public:
	glm::vec3* vertices[3];

	Triangle(glm::vec3 v1, glm::vec3 v2, glm::vec3 v3);
};