#include "Channel.h"

Channel::Channel(Tokenizer &token) {
	// Assuming we already opened the anim
	// file, and have skipped "channel {"
	char temp[256];
	token.GetToken(temp);
	if (strcmp(temp, "extrapolate") == 0) {
		token.GetToken(temp);
		if (strcmp(temp, "constant") == 0) {
			extra_in = "constant";
		}
		else if (strcmp(temp, "linear") == 0) {
			extra_in = "linear";
		}
		else if (strcmp(temp, "cycle") == 0) {
			extra_in = "cycle";
		}
		else if (strcmp(temp, "cycle_offset") == 0) {
			extra_in = "cycle_offset";
		}
		else if (strcmp(temp, "bounce") == 0) {
			extra_in = "bounce";
		}
		else {
			extra_in = "none";
		}
		token.GetToken(temp);
		if (strcmp(temp, "constant") == 0) {
			extra_out = "constant";
		}
		else if (strcmp(temp, "linear") == 0) {
			extra_out = "linear";
		}
		else if (strcmp(temp, "cycle") == 0) {
			extra_out = "cycle";
		}
		else if (strcmp(temp, "cycle_offset") == 0) {
			extra_out = "cycle_offset";
		}
		else if (strcmp(temp, "bounce") == 0) {
			extra_out = "bounce";
		}
		else {
			extra_out = "none";
		}
	}
	// Continue to keys
	token.GetToken(temp);
	if (strcmp(temp, "keys") == 0) {
		int numK = token.GetInt();
		int first_t, last_t, first_v, last_v;
		first_t = 0;
		first_v = 0;
		last_t = 0;
		last_v = 0;
		token.SkipLine(); // Skip the "{"
		for (int i = 0; i < numK; i++) {
			std::string t_in, t_out;
			float t = token.GetFloat();
			float v = token.GetFloat();
			if (i == 0) { // Earliest key
				first_t = t;
				first_v = v;
			}
			else if (i == numK - 1) {// last key
				last_t = t;
				last_v = v;
			}
			token.GetToken(temp); // tan in
			if (strcmp(temp, "flat") == 0) {
				t_in = "flat";
			}
			else if (strcmp(temp, "linear") == 0) {
				t_in = "linear";
			}
			else if (strcmp(temp, "smooth") == 0) {
				t_in = "smooth";
			}
			else {
				t_in = "fixed";
			}
			token.GetToken(temp); // tan out
			if (strcmp(temp, "flat") == 0) {
				t_out = "flat";
			}
			else if (strcmp(temp, "linear") == 0) {
				t_out = "linear";
			}
			else if (strcmp(temp, "smooth") == 0) {
				t_out = "smooth";
			}
			else {
				t_out = "fixed";
			}
			// Now, with all the info, make the key
			Keyframe* k = new Keyframe(t, v, t_in, t_out);
			keys.push_back(k);
		}
		// record start_time,end_time,period,offset
		start_time = first_t;
		end_time = last_t;
		offset = last_v - first_v;
		period = end_time - start_time;
		token.SkipWhitespace();
		token.SkipLine(); // skip	"}"
		token.SkipLine(); // skip "}"
		// All keys pushed back now, initialization complete
	}
}

void Channel::InitializeCubics() {
	 // Go through all keys, then initialize their
	// cubic parameters 
	for (int i = 0; i < keys.size() - 1; i++) // don't do this
												// for last one
	{
		keys[i]->deltaT = keys[i + 1]->time - keys[i]->time;
		
		float p0 = keys[i]->value;
		float p1 = keys[i + 1]->value;
		float t_v0 = keys[i]->deltaT * keys[i]->tangent_out;
		float t_v1 = keys[i]->deltaT * keys[i + 1]->tangent_in;

		// Just going to directly apply the equations to each
		// coefficient, instead of matrix
		keys[i]->A = (2 * p0) + (-2 * p1) + t_v0 + t_v1;
		keys[i]->B = (-3 * p0) + (3 * p1) + (-2 * t_v0) + (-t_v1);
		keys[i]->C = t_v0;
		keys[i]->D = p0;
	}
}

void Channel::InitializeTangents() {

	
	if (keys.size() == 1) { // There's only 1 keyframe
		if (keys[0]->rule_in.compare("linear") == 0 ||
			keys[0]->rule_in.compare("smooth") == 0) {
			keys[0]->tangent_in = 0;
		}
		if (keys[0]->rule_out.compare("linear") == 0 ||
			keys[0]->rule_out.compare("smooth") == 0) {
			keys[0]->tangent_out = 0;
		}
	}
	else { // There are more than 1 keys
		for (int i = 0; i < keys.size(); i++) {
			if (i == 0) { // first key
				if (keys[i]->rule_out.compare("linear") == 0 ||
					keys[i]->rule_out.compare("smooth") == 0) {
					keys[i]->tangent_out = 
						keys[i + 1]->value - keys[i]->value /
							(keys[i + 1]->time - keys[i]->time);
				}
			}
			else if (i == keys.size()-1){ // last key, dc about tanout
				if (keys[i]->rule_in.compare("linear") == 0 ||
					keys[i]->rule_in.compare("smooth") == 0) {
					keys[i]->tangent_in =
						keys[i]->value - keys[i-1]->value /
						(keys[i]->time - keys[i-1]->time);
				}
			}
			else { // Every key in between
				if (keys[i]->rule_in.compare("linear") == 0) {
					keys[i]->tangent_in =
						keys[i]->value - keys[i-1]->value /
						(keys[i]->time - keys[i-1]->time);
				}
				else if (keys[i]->rule_in.compare("smooth") == 0) {
					keys[i]->tangent_in =
						keys[i + 1]->value - keys[i - 1]->value /
						(keys[i+1]->time - keys[i - 1]->time);
					keys[i]->tangent_out = keys[i]->tangent_in;
				}

				if (keys[i]->rule_out.compare("linear") == 0) {
					keys[i]->tangent_out =
						keys[i + 1]->value - keys[i]->value /
						(keys[i + 1]->time - keys[i]->time);
				}
			}
		}
	}
	
}

float Channel::Evaluate(float t) {
	float val_offset = 0.0f;
	int loops = 0; // # of loops done from cyclic or bounce
	std::vector<Keyframe*>::iterator it;


	if (t <= start_time) {
		if (extra_in.compare("constant") == 0 ||
			extra_in.compare("none") == 0) {
			return keys.front()->value;
		}
		else if (extra_in.compare("linear") == 0) {
			return tangent_start * (t - start_time) + keys.front()->value;
		}
		else if (extra_in.compare("cycle") == 0) {
			loops = (end_time - t) / period;
			t += loops * period;
		}
		else if (extra_in.compare("cycle_offset") == 0) {
			loops = (end_time - t) / period;
			t += loops * period;
			val_offset = -1 * offset * loops;
		}
		else if (extra_in.compare("bounce") == 0) {
			loops = (end_time - t) / period;
			t += loops * period;
			if (loops % 2 == 1) {
				t = start_time + end_time - t;
			}
		}
	}
	else if (t >= end_time) {
		if (extra_out.compare("constant") == 0 ||
			extra_out.compare("none") == 0) {
			return keys.back()->value;
		}
		else if (extra_out.compare("linear") == 0) {
			return tangent_end * (t - end_time) + keys.back()->value;
		}
		else if (extra_out.compare("cycle") == 0) {
			loops = (t - start_time) / period;
			t -= loops * period;
		}
		else if (extra_out.compare("cycle_offset") == 0) {
			loops = (t - start_time) / period;
			t -= loops * period;
			val_offset = offset * loops;
		}
		else if (extra_out.compare("bounce") == 0) {
			loops = (t - start_time) / period;
			t -= loops * period;
			if (loops % 2 == 1) {
				t = start_time + end_time - t;
			}
		}
	}


	it = std::lower_bound(keys.begin(), keys.end(), t,
		[&](Keyframe* key, float t)->bool
		{
			return key->time < t;
		});

	if (it == keys.begin()) // start frame, evaluate at t=0
		return (*it)->Evaluate(0.0f) + val_offset;
	// otherwise, do prev key
	it--;
	return (*it)->Evaluate(t) + val_offset;
}

Channel::~Channel() {
	for (int i = 0; i < keys.size(); i++) {
		delete keys[i];
	}
}