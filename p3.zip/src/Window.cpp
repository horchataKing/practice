#include "imgui/imgui_impl_glfw.h"
#include "imgui/imgui_impl_opengl3.h"
#include "Window.h"

// Window Properties
int Window::width;
int Window::height;
const char* Window::windowTitle = "Model Environment";

// Objects to render -> Changed to skeleton
Skeleton* Window::skeleton;
// Animation player
AnimationPlayer* Window::animationPlayer;
// File names
char* Window::skelName = "..wasp/wasp.skel";
char* Window::skinName = "..wasp/wasp.skin";
char* Window::animName = "..wasp/wasp.anim";

// Camera Properties
Camera* Cam;

// Interaction Variables
bool LeftDown, RightDown;
int MouseX, MouseY;

// Joint pointer used to reference specific joints for IMGUI
Joint* Window::currJoint;
int Window::jntIndex;

// The shader program id
GLuint Window::shaderProgram;

// Constructors and desctructors
bool Window::initializeProgram() {
    // Create a shader program with a vertex shader and a fragment shader.
    shaderProgram = LoadShaders("shaders/shader.vert", "shaders/shader.frag");

    // Check the shader program.
    if (!shaderProgram) {
        std::cerr << "Failed to initialize shader program" << std::endl;
        return false;
    }

    return true;
}

bool Window::initializeObjects() {
    // Create a skeleton and skin
    if (strcmp(skelName, "") == 0) {
        printf("Skel name not found/valid");
        return false;
    }
    if (strcmp(skinName, "") == 0) {
        printf("skin name not found/valid");
        return false;
    }
    if (strcmp(animName, "") == 0) {
        printf("anim name not found/valid");
        return false;
    }

    skeleton = new Skeleton();
    animationPlayer = new AnimationPlayer(skeleton);
    //const char* skelName = "../tube.skel";
    //const char* skinName = "../tube.skin";
    skelName = "../wasp/wasp.skel";
    skinName = "../wasp/wasp.skin";
    animName = "../wasp/wasp_walk.anim";
    //"..wasp/wasp.skin"
    // //"..wasp/wasp.skel"
    // //"..wasp/wasp.anim"
    //cube = new Cube(glm::vec3(-1, 0, -2), glm::vec3(1, 1, 1));
    skeleton->Load(skelName,skinName);
    animationPlayer->Load(animName);

    
    jntIndex = 0;
    currJoint = skeleton->joints[jntIndex];
    //skeleton->Load("../wasp.skel");
    //skeleton->Load("../dragon.skel");
    return true;
}

void Window::cleanUp() {
    // Deallcoate the objects.
    delete skeleton;
    delete animationPlayer;

    // Delete the shader program.
    glDeleteProgram(shaderProgram);
}

// for the Window
GLFWwindow* Window::createWindow(int width, int height) {
    // Initialize GLFW.
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return NULL;
    }

    // 4x antialiasing.
    glfwWindowHint(GLFW_SAMPLES, 4);

    // Create the GLFW window.
    GLFWwindow* window = glfwCreateWindow(width, height, windowTitle, NULL, NULL);

    // Check if the window could not be created.
    if (!window) {
        std::cerr << "Failed to open GLFW window." << std::endl;
        glfwTerminate();
        return NULL;
    }

    // Make the context of the window.
    glfwMakeContextCurrent(window);

    // Initialize GLEW
    glewInit();

    // Set swap interval to 1.
    glfwSwapInterval(0);

    // set up the camera
    Cam = new Camera();
    Cam->SetAspect(float(width) / float(height));

    // initialize the interaction variables
    LeftDown = RightDown = false;
    MouseX = MouseY = 0;

    // Call the resize callback to make sure things get drawn immediately.
    Window::resizeCallback(window, width, height);

    return window;
}

void Window::resizeCallback(GLFWwindow* window, int width, int height) {
    Window::width = width;
    Window::height = height;
    // Set the viewport size.
    glViewport(0, 0, width, height);

    Cam->SetAspect(float(width) / float(height));
}

// update and draw functions
void Window::idleCallback() {
    // Perform any updates as necessary.
    Cam->Update();

    //skeleton->Update();
    // Have animationPlayer update everything
    animationPlayer->Update();
}

void Window::displayCallback(GLFWwindow* window) {
    //rotxlimit = glm::vec2(-100000, 100000);
    float default_bound = 100000;
    float lower_bound, higher_bound;
    // Clear the color and depth buffers.
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Render the object.
    skeleton->Draw(Cam->GetViewProjectMtx(), Window::shaderProgram);
  
    // Gets events, including input such as keyboard and mouse or window resizing.
    glfwPollEvents();

    // ==========IMGUI==========
    //start imgui new frame
    //ImGui_ImplOpenGL3_NewFrame();
    //ImGui_ImplGlfw_NewFrame();
    //ImGui::NewFrame();

    ImGuiWindowFlags window_flags = 0;
    //window_flags |= ImGuiWindowFlags_NoInputs;
    window_flags |= ImGuiWindowFlags_NoResize;
    //gui window
    ImGui::Begin("DOFs", NULL, window_flags);
    ImGui::SetWindowPos(ImVec2(Window::width - 190, 0));
    ImGui::SetWindowSize(ImVec2(190, Window::height));
    ImGui::Text("Joint ID: %d", jntIndex);
    
    // If rotation limits are default, just use -180 & 180
    lower_bound = currJoint->pose_vector[0].min;
    if (lower_bound == -default_bound) {
        lower_bound = glm::radians(-180.0f);
    }
    higher_bound = currJoint->pose_vector[0].max;
    if (higher_bound == default_bound) {
        higher_bound = glm::radians(180.0f);
    }

    ImGui::SliderFloat("RotX", &currJoint->pose_vector[0].value,
                                //currJoint->pose_vector[0].min, currJoint->pose_vector[0].max,
                                lower_bound, higher_bound,
                                NULL,ImGuiSliderFlags_AlwaysClamp);
    ImGui::SliderFloat("RotY", &currJoint->pose_vector[1].value,
                                lower_bound, higher_bound,
                                NULL, ImGuiSliderFlags_AlwaysClamp);
        
    ImGui::SliderFloat("RotZ", &currJoint->pose_vector[2].value,
                                lower_bound, higher_bound,
                                NULL, ImGuiSliderFlags_AlwaysClamp);
    
    if (ImGui::Button("->")) {
        jntIndex = (jntIndex + 1) % skeleton->joints.size();
        currJoint = skeleton->joints[jntIndex];
    }
    if (ImGui::Button("<-")) {
        if (jntIndex - 1 == -1)
            jntIndex = skeleton->joints.size()-1;
        else
            jntIndex--;
        currJoint = skeleton->joints[jntIndex];
    }
    if (ImGui::Button("Reset DOF for X")) {
        currJoint->pose_vector[0].ResetDOF();
    }
    if (ImGui::Button("Reset DOF for Y")) {
        currJoint->pose_vector[1].ResetDOF();
    }
    if (ImGui::Button("Reset DOF for Z")) {
        currJoint->pose_vector[2].ResetDOF();
    }
    ImGui::End();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    // =========================
    // Swap buffers.
    glfwSwapBuffers(window);
}

// helper to reset the camera
void Window::resetCamera() {
    Cam->Reset();
    Cam->SetAspect(float(Window::width) / float(Window::height));
}

// callbacks - for Interaction
void Window::keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    /*
     * TODO: Modify below to add your key callbacks.
     */

    // Check for a key press.
    if (action == GLFW_PRESS) {
        switch (key) {
            case GLFW_KEY_ESCAPE:
                // Close the window. This causes the program to also terminate.
                glfwSetWindowShouldClose(window, GL_TRUE);
                break;

            case GLFW_KEY_R:
                resetCamera();
                break;

            default:
                break;
        }
    }
}

void Window::mouse_callback(GLFWwindow* window, int button, int action, int mods) {
    if (button == GLFW_MOUSE_BUTTON_LEFT) {
        LeftDown = (action == GLFW_PRESS);
    }
    if (button == GLFW_MOUSE_BUTTON_RIGHT) {
        RightDown = (action == GLFW_PRESS);
    }
}

void Window::cursor_callback(GLFWwindow* window, double currX, double currY) {
    int maxDelta = 100;
    int dx = glm::clamp((int)currX - MouseX, -maxDelta, maxDelta);
    int dy = glm::clamp(-((int)currY - MouseY), -maxDelta, maxDelta);

    MouseX = (int)currX;
    MouseY = (int)currY;

    // Move camera
    // NOTE: this should really be part of Camera::Update()
    if (LeftDown) {
        const float rate = 1.0f;
        Cam->SetAzimuth(Cam->GetAzimuth() + dx * rate);
        Cam->SetIncline(glm::clamp(Cam->GetIncline() - dy * rate, -90.0f, 90.0f));
    }
    if (RightDown) {
        const float rate = 0.005f;
        float dist = glm::clamp(Cam->GetDistance() * (1.0f - dx * rate), 0.01f, 1000.0f);
        Cam->SetDistance(dist);
    }
}