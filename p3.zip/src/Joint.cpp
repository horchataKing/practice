#include "Joint.h"

Joint::Joint()
{
	// ==========Initialize variables==========

	// explicitly set dofNum to be 3, for balljoints
	dofNum = 3;
	dofX = 0;
	dofY = 0;
	dofZ = 0;
	// Expand the pose_vector to make space for 3 DOF
	for (int i = 0; i < dofNum; i++)
		pose_vector.push_back(DOF());

	// Initialize the matrices to just the identity matrix
	local = glm::identity<glm::mat4>();
	world = glm::identity<glm::mat4>();
	// Give vectors their default values
	offset = glm::vec3(0,0,0);
	boxMin = glm::vec3(-0.1, -0.1, -0.1);
	boxMax = glm::vec3(0.1, 0.1, 0.1);
	rotxlimit = glm::vec2(-100000, 100000);
	rotylimit = glm::vec2(-100000, 100000);
	rotzlimit = glm::vec2(-100000, 100000);
}

Joint::~Joint()
{
	delete box;
	// Maybe delete children?
	for (Joint* j: children)
	{
		delete j;
	}
}

void Joint::Update(glm::mat4* parent)
{
	// ==Compute local matrix==
	// Get Angles for each axis
	float theta_X = pose_vector[0].GetValue();
	float theta_Y = pose_vector[1].GetValue();
	float theta_Z = pose_vector[2].GetValue();
	

	glm::mat4 T = glm::translate(glm::mat4(1),offset);
	glm::mat4 rotz = glm::rotate(glm::mat4(1), theta_Z, glm::vec3(0, 0, 1));
	glm::mat4 roty = glm::rotate(glm::mat4(1), theta_Y, glm::vec3(0, 1, 0));
	glm::mat4 rotx = glm::rotate(glm::mat4(1), theta_X, glm::vec3(1, 0, 0));

	local = T * rotz * roty * rotx;

	// Compute world matrix
	//world = glm::dot(*parent, local);
	world = *parent * local;

	
	// Recursively call Update on children
	for (Joint* child:children)
	{
		child->Update(&world);
	}
}

bool Joint::Load(Tokenizer& token, std::vector<Joint*> *joints)
{
	token.FindToken("{");
	while(1)
	{
		char temp[256];
		token.GetToken(temp);
		// If term offset found, record it
		if (strcmp(temp, "offset") == 0)
		{
			offset.x = token.GetFloat();
			offset.y = token.GetFloat();
			offset.z = token.GetFloat();
		}
		// If term boxmin found, record it
		else if (strcmp(temp, "boxmin") == 0)
		{
			boxMin.x = token.GetFloat();
			boxMin.y = token.GetFloat();
			boxMin.z = token.GetFloat();
		}
		// If term boxmax found, record it
		else if (strcmp(temp, "boxmax") == 0)
		{
			boxMax.x = token.GetFloat();
			boxMax.y = token.GetFloat();
			boxMax.z = token.GetFloat();
		}
		// If term pose found, record it
		else if (strcmp(temp, "pose") == 0)
		{
			dofX = token.GetFloat();
			dofY = token.GetFloat();
			dofZ = token.GetFloat();
		}
		// If term rotlimit found, record it
		else if (strcmp(temp, "rotxlimit") == 0)
		{
			rotxlimit.x = token.GetFloat();
			rotxlimit.y = token.GetFloat();
		}
		else if (strcmp(temp, "rotylimit") == 0)
		{
			rotylimit.x = token.GetFloat();
			rotylimit.y = token.GetFloat();
		}
		else if (strcmp(temp, "rotzlimit") == 0)
		{
			rotzlimit.x = token.GetFloat();
			rotzlimit.y = token.GetFloat();
		}
		// If term balljoint found, load in new joint
		else if (strcmp(temp, "balljoint") == 0)
		{
			Joint* jnt = new Joint();
			//joints->push_back(jnt);
			AddChild(jnt, joints);
			jnt->Load(token,joints);
		}
		else if (strcmp(temp, "}") == 0)
		{
			// Done getting input, now load box and set minmax for each DOF
			pose_vector[0].SetMinMax(rotxlimit.x, rotxlimit.y);
			pose_vector[1].SetMinMax(rotylimit.x, rotylimit.y);
			pose_vector[2].SetMinMax(rotzlimit.x, rotzlimit.y);

			pose_vector[0].SetValue(dofX);
			pose_vector[0].SetOriginal(dofX);
			pose_vector[1].SetValue(dofY);
			pose_vector[1].SetOriginal(dofY);
			pose_vector[2].SetValue(dofZ);
			pose_vector[2].SetOriginal(dofZ);
			box = new Cube(boxMin, boxMax);
			return true;
		}
		else token.SkipLine(); // Unrecognized token
	}
}

void Joint::AddChild(Joint* child, std::vector<Joint*>* joints)
{
	children.push_back(child);
	child->parent = this;
	// Keep track in joints
	joints->push_back(child);

}

void Joint::Draw(const glm::mat4& viewProjMtx, GLuint shader)
{
	// Draw orientated box with OpenGL
	box->draw(viewProjMtx * world,shader);
	// Recursively call Draw() on children
	for (Joint* child: children)
	{
		//child->Draw(viewProjMtx * world, shader);
		child->Draw(viewProjMtx, shader);
	}
}


