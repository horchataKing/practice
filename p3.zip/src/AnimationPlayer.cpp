#include "AnimationPlayer.h"
AnimationPlayer::AnimationPlayer(Skeleton* s) {
	skel = s;
	animation = nullptr;
	time = (float)clock();
	prevTime = (float)clock();
}
AnimationPlayer::~AnimationPlayer() {
}
void AnimationPlayer::Load(char* file) {
		Tokenizer token;
		token.Open(file);
		char temp[256];
		token.GetToken(temp);
		// If term offset found, record it
		if (strcmp(temp, "animation") == 0) {
			animation = new Animation(token);
		}
		token.Close(); // close this token
		// initialize all channels,tangents,cubics
		animation->InitializeChannels();
}
void AnimationPlayer::Update() {
	clock_t currentTime= clock();
	time += (currentTime = prevTime) / 1000.0f;
	if (time < animation->start_time || time > animation->end_time)
		time = animation->start_time;
	glm::mat4 T = glm::mat4(1.0f);
	animation->Update(time, T, skel);
	skel->Update(T);
	
	
}
