#include "Skin.h"
Skin::Skin(Tokenizer& token) {
	Load(token);
}
bool Skin::Load(Tokenizer& token)
{
	//bool began = 0;
	//token.FindToken("positions");
	while(1)
	{
		char temp[256];
		token.GetToken(temp);
		// If term offset found, record it
		if (strcmp(temp, "positions") == 0)
		{
			int numverts = token.GetInt();
			token.SkipLine(); // Skin "{"
			for (int i = 0; i < numverts; i++)
			{
				float x = token.GetFloat();
				float y = token.GetFloat();
				float z = token.GetFloat();

				positions.push_back(glm::vec3(x, y, z));
			}
			token.SkipLine(); // Skip "}"
		}
		else if(strcmp(temp, "normals") == 0)
		{
			int numNormals = token.GetInt();
			token.SkipLine();
			for (int i = 0; i < numNormals; i++)
			{
				glm::vec3 n;
				n.x = token.GetFloat();
				n.y = token.GetFloat();
				n.z = token.GetFloat();

				normals.push_back(glm::normalize(n));
				//normals.push_back(n);
			}
			token.SkipLine();
		}
		else if(strcmp(temp, "skinweights") == 0)
		{	
			int numVerts = token.GetInt();
			token.SkipLine();
			for (int i = 0; i < numVerts; i++)
			{
				std::vector<float> weightVec;
				std::vector<GLuint> indexVec;
				int numAttatchments = token.GetInt();
				for(int j = 0; j < numAttatchments; j++)
				{
					int jointNum = token.GetInt();
					float weight = token.GetFloat();
					indexVec.push_back(jointNum);
					weightVec.push_back(weight);
				}
				// Push back these filled vectors into our
				// vectors of vectors
				skinWeights.push_back(weightVec);
				joint_indices.push_back(indexVec);
				
			}
			token.SkipLine();
		}
		else if (strcmp(temp, "triangles") == 0)
		{
			int numTri = token.GetInt();
			token.SkipLine();
			for (int i = 0; i < numTri; i++)
			{
				int v1 = token.GetInt();
				int v2 = token.GetInt();
				int v3 = token.GetInt();
				//triangles.push_back(Triangle(positions[v1], positions[v2], positions[v3]));
				indices.push_back(v1);
				indices.push_back(v2);
				indices.push_back(v3);
			}
			token.SkipLine();
		}
		else if (strcmp(temp, "bindings") == 0)
		{
			glm::vec4 a,b,c,d;
			float ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz;
			int numJoints = token.GetInt();
			token.SkipLine(); // skip {
			//printf("found open bracket: %d\n",token.FindToken("{")); // skip bracket {
			for (int i = 0; i < numJoints; i++)
			{
				token.SkipLine(); // skip the 'matrix {' line
				//token.GetToken(temp);
				//if (strcmp(temp, "matrix") == 0) { // Ensuring matrix found
					//token.SkipLine(); // Skip bracket "{"
					// feed values of matrix into a matrix, store it
					ax = token.GetFloat();
					ay = token.GetFloat();
					az = token.GetFloat();
					bx = token.GetFloat();
					by = token.GetFloat();
					bz = token.GetFloat();
					cx = token.GetFloat();
					cy = token.GetFloat();
					cz = token.GetFloat();
					dx = token.GetFloat();
					dy = token.GetFloat();
					dz = token.GetFloat();
					a = glm::vec4(ax, ay, az, 0);
					b = glm::vec4(bx, by, bz, 0);
					c = glm::vec4(cx, cy, cz, 0);
					d = glm::vec4(dx, dy, dz, 1);
					// Finally, push back a matrix, and 
					// store its inversion as well
					glm::mat4 newMat = glm::mat4(a, b, c, d);
					// gonna print the new mat
					bindings.push_back(newMat);
					glm::mat4 newInvertedMat = glm::inverse(newMat);
					invertedB.push_back(newInvertedMat);
					token.SkipLine(); // Skip end of line
					token.SkipLine(); // skip closing bracket
				//}
			}
			token.SkipLine();
			// Now that all matricies are accounted for, call 
			// geometry load and return true
			GeometryLoad();
			return true;

		}
		else token.SkipLine(); // Unrecognized token

	}
}

void Skin::Update(std::vector<Joint*> *joints)
{	

	// update positions & normals 
	// Positions first
	glBindBuffer(GL_ARRAY_BUFFER, VBO_positions);
	for (int i = 0; i < positions.size(); i++) { // positions.size == skinW.size
		glm::vec4 result(0.0f);
		glm::vec3 new_v(0.0f);
		glm::vec4 pos4 = glm::vec4(positions[i], 1.0f); // for each vertex
		for (int j = 0; j < skinWeights[i].size(); j++) { // for numAttatchements
			int jointIndex = joint_indices[i][j];	
			glm::mat4 skinM = (*joints)[jointIndex]->world * invertedB[jointIndex];
			result += skinWeights[i][j] * skinM * pos4;
		}
		new_v += glm::vec3(result.x/result.w, result.y/result.w, result.z/result.w);
		//new_v += glm::vec3(result);
		//positions[i] = new_v;
		glBufferSubData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * i, sizeof(glm::vec3), &new_v);
	}
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	// Now, normals
	glBindBuffer(GL_ARRAY_BUFFER, VBO_normals);
	for (int i = 0; i < normals.size(); i++) {
		glm::vec4 result(0.0f);
		glm::vec3 n_star(0.0f); // hold un homogenized normal
		glm::vec3 new_n(0.0f);
		glm::vec4 norm4 = glm::vec4(normals[i], 0.0f);
		for (int j = 0; j < skinWeights[i].size(); j++) {

			int jointIndex = joint_indices[i][j];
			glm::mat4 skinM = (*joints)[jointIndex]->world * invertedB[jointIndex];
			result += skinWeights[i][j] * skinM * norm4;
			// Still need to re-normalize final result
		}
		n_star = glm::normalize(result);
		//new_n = glm::normalize(n_star);
		new_n = glm::vec3(n_star);
		//normals[i] = new_n;
		glBufferSubData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * i, sizeof(glm::vec3), &new_n);
		
	}
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void Skin::Draw(const glm::mat4& viewProjMtx, GLuint shader)
{
	glUseProgram(shader);

	glUniformMatrix4fv(glGetUniformLocation(shader, "viewProj"), 1, GL_FALSE, (float*)&viewProjMtx);
	glUniformMatrix4fv(glGetUniformLocation(shader, "model"), 1, GL_FALSE, (float*)&model);
	glUniform3fv(glGetUniformLocation(shader, "DiffuseColor"), 1, &color[0]);

	// Bind the VAO
	glBindVertexArray(VAO);

	// draw the points using triangles, indexed with the EBO
	glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(indices.size()), GL_UNSIGNED_INT, 0);

	// Unbind the VAO and shader program
	glBindVertexArray(0);
	glUseProgram(0);

}
void Skin::GeometryLoad() 
{
	// Generate a vertex array (VAO) and two vertex buffer objects (VBO)
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO_positions);
	glGenBuffers(1, &VBO_normals);

	// Bind to the VAO
	glBindVertexArray(VAO);

	// Bind to the first VBO - We will use it to store the vertices
	glBindBuffer(GL_ARRAY_BUFFER, VBO_positions);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * positions.size(),positions.data(), GL_DYNAMIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);

	// Bind to the second VBO - we will use it to store the normals
	glBindBuffer(GL_ARRAY_BUFFER, VBO_normals);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * normals.size(), normals.data(), GL_DYNAMIC_DRAW);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);

	// Generate EBO, bind the EBO to the bound VAO and send the data

	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint) * indices.size(), indices.data(), GL_STATIC_DRAW);

	// Unbind the VBOs
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

Skin::~Skin() {
	// Delete the VBOs and the VAO.
	glDeleteBuffers(1, &VBO_positions);
	glDeleteBuffers(1, &VBO_normals);
	glDeleteBuffers(1, &EBO);
	glDeleteVertexArrays(1, &VAO);
}