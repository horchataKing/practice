#include "Skeleton.h"
bool Skeleton::Load(const char* skelFile, const char* skinFile)
{
	Tokenizer token;
	if (!token.Open(skelFile))
		return false; // Error checking
	token.FindToken("balljoint");

	// Parse tree
	root = new Joint();
	joints.push_back(root);
	root->Load(token, &joints);
	
	//Finish skell
	token.Close();

	// Onto skin file
	if (!token.Open(skinFile))
		return false; // Return error if no skin file
	// Parse skin file
	skin = new Skin(token);
	//skin->Load(token);
	// Close token
	token.Close();

	return true;
}
void Skeleton::Update()
{
	// Call update on root, which will then call update on
	// all of its children
	glm::mat4 identity_mat = glm::mat4(1);
	root->Update(&identity_mat);
	skin->Update(&joints);
}
void Skeleton::Update(glm::mat4& T) { // For proj3 animations
	root->Update(&T);
	skin->Update(&joints);

}
void Skeleton::Draw(const glm::mat4& viewProjMtx, GLuint shader)
{
	// Pass parameters into the root Joint's Draw(), so it
	// can use the same parameters on its cube and children
	root->Draw(viewProjMtx, shader);
	skin->Draw(viewProjMtx, shader);
}

Skeleton::Skeleton() {
	root = nullptr;
	skin = nullptr;
}
Skeleton::~Skeleton()
{
	delete root;
	delete skin;
}


