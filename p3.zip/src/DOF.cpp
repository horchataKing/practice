#include "DOF.h"
DOF::DOF()
{
	value = 0.0f;
	original_val = value;
	min = -100000;
	max = 100000;
}
float DOF::GetValue()
{
	if (value < min)
		value = min;
	else if (value > max)
		value = max;

	return value;
}
void DOF::SetMinMax(float inMin, float inMax)
{
	min = inMin;
	max = inMax;
	// Adjust the value of DOF to be within the new
	// min and max
	SetValue(value);
}

void DOF::SetValue(float v)
{
	if (v < min) 
		value = min;
	else if (v > max) 
		value = max;
	else
		value = v;
}
void DOF::SetOriginal(float v) {
	if (v < min)
		original_val = min;
	else if (v > max)
		original_val = max;
	else
		original_val = v;
}
void DOF::ResetDOF(){
	value = original_val;
}


