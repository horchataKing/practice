#include "Keyframe.h"
Keyframe::Keyframe(float t, float v, std::string in, std::string  out) {
	deltaT = 1.0f;
	time = t;
	value = v;
	tangent_in = 0.0f;
	tangent_out = 0.0f;
	A = 0;
	B = 0;
	C = 0;
	D = v;
	rule_in = in;
	rule_out = out;
}

float Keyframe::Evaluate(float t) {
	float u, x;
	u = (t - time) / deltaT;
	x = D + u * (C + u * (B + u * A));
	return x;
}