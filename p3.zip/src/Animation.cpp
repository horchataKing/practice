#include "Animation.h"
Animation::Animation(Tokenizer &token) {
	// We're already assuming that the token
	// is opened and reading an anim file
	while (1) {
		char temp[256];
		token.SkipLine(); // skip {
		token.GetToken(temp);
		if (strcmp(temp, "range") == 0)
		{
			int startTime = token.GetFloat();
			int endTime = token.GetFloat();
			start_time = startTime;
			end_time = endTime;
		}
		else if (strcmp(temp, "numchannels") == 0)
		{
			int numChannels = token.GetInt();
			//channels.resize(numChannels);
			token.GetToken(temp); // ensuring next
			// possible line is at "channel"
			if (strcmp(temp, "channel") == 0) {
				for (int i = 0; i < numChannels; i++) {
					token.SkipLine(); // Skip the "channel # {"
					Channel* ch = new Channel(token);
					channels.push_back(ch);
				}
			}
			else {
				printf("Animation error");
				return;
			}


			// Now that all channels are loaded, exit
			return;

		}
		else token.SkipLine(); // Unrecognized token
	}
	

}

void Animation::InitializeChannels() {
	//for (Channel* ch : channels) {
	for (int i = 0; i < channels.size(); i++){
		channels[i]->InitializeTangents();
		channels[i]->InitializeCubics();
		channels[i]->tangent_start = channels[i]->keys.front()->tangent_in;
		channels[i]->tangent_end = channels[i]->keys.front()->tangent_out;
	}

}

void Animation::Update(float t, glm::mat4& T ,Skeleton* skel) {
	glm::vec3 pos;
	
	pos.x = channels[0]->Evaluate(t);
	pos.y = channels[1]->Evaluate(t);
	pos.z = channels[2]->Evaluate(t);
	T = glm::translate(pos);

	for (int i = 0; i < skel->joints.size(); i++) {
		float x, y, z;
		x = channels[(3 * i) + 3]->Evaluate(t);
		y = channels[(3 * i) + 4]->Evaluate(t);
		z = channels[(3 * i) + 5]->Evaluate(t);
		skel->joints[i]->pose_vector[0].SetValue(x);
		skel->joints[i]->pose_vector[1].SetValue(y);
		skel->joints[i]->pose_vector[2].SetValue(z);
	}
}

Animation::~Animation() {
	for (int i = 0; i < channels.size(); i++) {
		delete channels[i];
	}
}