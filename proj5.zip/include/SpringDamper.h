#pragma once

#include "Particle.h"

class SpringDamper
{
public:

	float SpringConst;
	float DampingConst;
	float RestLength;
	Particle* P1, * P2;

	//glm::vec3 prevDir;


	SpringDamper(Particle* p1, Particle* p2, float SpringConst, float DampingConst, float RestLength);


	void ComputeForce();

};
