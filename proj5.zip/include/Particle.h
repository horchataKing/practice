#pragma once

#include "core.h"

class Particle
{
public:
	// System details, will be derived from system
	float lifeSpan;
	float* mass;
	float* gravity;
	float* airDensity;
	float* dragCoeff;
	float* radius;
	float* collisionElasticity;
	float* collisionFriction;
	glm::vec3* windSpeed;
	glm::vec3* groundTop;
	glm::vec3* groundBot;

	// Particles own parameters
	glm::vec3 position;
	glm::vec3 velocity;
	glm::vec3 force;
	bool isAlive = false;
	glm::vec3 color;
	
	// Epsilon
	float epsilon;
	//const float* gravityAcce;
	//const float* groundPos;


	Particle( float *mass,
		float* r, float* gravity, float* aDens, float* drag,
		glm::vec3* wSpeed, float* elasticity, float* friction
		, glm::vec3* gndTop, glm::vec3* gndBot, float span);

	void Update(float deltaT);
	void ApplyForce(glm::vec3 f);
	void ApplyGravity();
	void Integrate(float deltaTime);

	void ResetForce();

	//glm::vec3 GetVelocity();
	//glm::vec3 GetPosition();

	//void ResetNormal();
	//void AddNormal(glm::vec3 n);

	void GroundCollision();
};