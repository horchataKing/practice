#pragma once
#include "Particle.h"
#include "Ground.h"
#include <random>
/* Class for a system of particles. Will have a main component
 * That can vary from another particle to a particular shape
 * (in this case, will be a cube). This is meant to be the source.
 */
class ParticleSystem {
public:
	// The static 4 vertices (xyz -> 12 data points) of each particle, to be shared via instancing
	GLfloat g_vertex_buffer_data[12];

	std::vector<Particle*> particles;
	std::vector<glm::vec3> positions;
	std::vector<glm::vec3> colors;

	GLuint programID;
	//GLuint vao, vbos[3], ebo;
	// VBOs for specifically the vertices, positions, and colors of each particle
	GLuint VBOS[3];

	const static int maxParticles = 1000;
	GLfloat g_particle_position_size_data[maxParticles];
	// parameters to be shared with the particles
	float mass;
	float gravity;
	float airDensity;
	float dragCoeff;
	float radius;
	float collisionElasticity;
	float collisionFriction;
	glm::vec3 windSpeed;

	// Ground parameters
	glm::vec3 groundTop;
	glm::vec3 groundBot;

	// Creation related parameters
	float creationRate;
	float creationInterval = 0.0f;

	// Initial values for particles
	glm::vec3 initialPos;
	glm::vec3 initialPosVar;
	glm::vec3 initialVelocity;
	glm::vec3 initialVelocityVar;
	float initialLifeSpan;
	float initialLifeSpanVar;

	float prevT;

	int lastIdx = 0;
	int particleCount = 0;

	glm::mat4 model;

	// Stuff to help generate particles randomly
	std::default_random_engine randEng;
	std::normal_distribution<float> randNormal;

	int overSample = 10;

	/* Functions */
	ParticleSystem(GLuint ID, glm::vec3 groundTop, glm::vec3 groundBot);
	~ParticleSystem();

	void LoadInstance();

	void Update();
	void Draw(const glm::mat4& viewProjMtx);
	int FindIdleParticle();

	/*
	float GetCreationRate() { return creationRate; }
	void SetCreationRate(float c) { creationRate = c; }
	float GetRadius() { return radius; }
	void SetRadius(float r)
	{
		radius = r;
		model = glm::scale(glm::vec3(r, r, r));
	}
	float GetMass() { return mass; }
	void SetMass(float m) { mass = m; }
	float GetGravity() { return g; }
	void SetGravity(float _g) { g = _g; }
	float GetAirDensity() { return airDensity; }
	void SetAirDensity(float rho) { airDensity = rho; }
	float GetDragConst() { return dragConst; }
	void SetDragConst(float c_d) { dragConst = c_d; }
	glm::vec3 GetWindSpeed() { return windSpeed; }
	void SetWindSpeed(glm::vec3 v) { windSpeed = v; }
	float GetElasticity() { return elasticity; }
	void SetElasticity(float e) { elasticity = e; }
	float GetFriction() { return friction; }
	void SetFriction(float f) { friction = f; }
	glm::vec3 GetGroundCenter() { return groundCenter; }
	void SetGroundCenter(glm::vec3 center)
	{
		if (center.y > initialPos.y - radius)
		{
			center.y = initialPos.y - radius;
		}
		groundCenter = center;
		groundTopLeft = groundCenter - glm::vec3(groundSize / 2.0f, 0.0f, groundSize / 2.0f);
		groundBottomRight = groundCenter + glm::vec3(groundSize / 2.0f, 0.0f, groundSize / 2.0f);
		ground->SetGroundCenter(groundCenter);
	}
	float GetGroundSize() { return groundSize; }
	void SetGroundSize(float size)
	{
		groundSize = size;
		groundTopLeft = groundCenter - glm::vec3(groundSize / 2.0f, 0.0f, groundSize / 2.0f);
		groundBottomRight = groundCenter + glm::vec3(groundSize / 2.0f, 0.0f, groundSize / 2.0f);
		ground->SetGroundSize(size);
	}
	glm::vec3 GetInitialPos() { return initialPos; }
	void SetInitialPos(glm::vec3 pos)
	{
		if (pos.y < groundCenter.y + radius)
		{
			pos.y = groundCenter.y + radius;
		}
		initialPos = pos;
	}
	glm::vec3 GetInitialPosVar() { return initialPosVar; }
	void SetInitialPosVar(glm::vec3 var) { initialPosVar = var; }
	glm::vec3 GetInitialVelocity() { return initialVelocity; }
	void SetInitialVelocity(glm::vec3 v) { initialVelocity = v; }
	glm::vec3 GetInitialVelocityVar() { return initialVelocityVar; }
	void SetInitialVelocityVar(glm::vec3 var) { initialVelocityVar = var; }
	float GetInitialLifeSpan() { return initialLifeSpan; }
	void SetInitialLifeSpan(float t) { initialLifeSpan = t; }
	float GetInitialLifeSpanVar() { return initialLifeSpanVar; }
	void SetInitialLifeSpanVar(float var) { initialLifeSpanVar = var; }
	*/
};