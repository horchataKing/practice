#include "SpringDamper.h"

SpringDamper::SpringDamper(Particle* p1, Particle* p2, float _SpringConst, float _DampingConst, float _RestLength)
{
	P1 = p1;
	P2 = p2;

	SpringConst = _SpringConst;
	DampingConst = _DampingConst;
	RestLength = _RestLength;

	//prevDir = P2->position - P1->position;
}

void SpringDamper::ComputeForce()
{
	glm::vec3 e = P2->position - P1->position;
	float length = glm::length(e);
	//if (length > EPSILON)
	//{
	e= glm::normalize(e);
		//prevDir = dir;
	//}
	//else
	//{
		//dir = prevDir;
		//currLength = 0.0f;
//		dir = glm::vec3(0.0f);
	//	currLength = 0.0f;
	//}

	
	// Compute closing velocity
	glm::vec3 v_diff = P1->velocity - P2->velocity;
	float v_close = glm::dot(v_diff,e);
	
	//Compute final forces
	float f = (-SpringConst * (RestLength - length)) - DampingConst * v_close;
	//fspring was above, but vec3
	//if (f_spring.length() < EPSILON) f_spring = glm::vec3(0.0f);
	glm::vec3 f1 = f * e;
	glm::vec3 f2 = -f1;
	//glm::vec3 f_damper = -(*DampingConst) * v * dir;
	//if (f_damper.length() < EPSILON) f_damper = glm::vec3(0.0f);


	P1->ApplyForce(f1);
	P2->ApplyForce(f2);
}