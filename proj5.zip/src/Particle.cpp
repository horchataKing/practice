#include "Particle.h"

Particle::Particle(float* m, float* r, float* g, float* aDens, 
	float* drag, glm::vec3* wSpeed, float* elasticity, float* friction
	, glm::vec3* gndTop, glm::vec3* gndBot, float span)
{
	lifeSpan = span;
	mass = m;
	radius = r;
	gravity = g;
	airDensity = aDens;
	dragCoeff = drag;
	windSpeed = wSpeed;
	collisionElasticity = elasticity;
	collisionFriction = friction;
	isAlive = true;

	//gravityAcce = _gravityAcce;
	//groundPos = _groundPos;
	position = glm::vec3(0.0f);
	color = glm::vec3(1.0f, 0.0f, 1.0f);
	velocity = glm::vec3(0.0f);
	force = glm::vec3(0.0f);
	//prevForce = glm::vec3(0.0f);
	epsilon = 0.005;
	groundTop = gndTop;
	groundBot = gndBot;
}


void Particle::Update(float deltaT)
{
	// Decrease lifespan
	lifeSpan -= deltaT;
	// check if the lifespan of the particle is out, and if so
	// mark the particle as dead
	if (lifeSpan < 0.0f)
	{
		lifeSpan = 0.0f;
		isAlive = false;
		return;
	}

	glm::vec3 force(0.0f, -(*gravity) * (*mass), 0.0f);
	glm::vec3 v_close = velocity - (*windSpeed);
	force -= 0.5f * (*airDensity) * glm::length(v_close) * v_close * (*dragCoeff)
		* glm::pi<float>() * (*radius) * (*radius);

	glm::vec3 acceleration = force / (*mass);
	velocity += acceleration * deltaT;
	position += velocity * deltaT;

	GroundCollision();
}

void Particle::ApplyForce(glm::vec3 f)
{
	force += f;
}

void Particle::ApplyGravity()
{
	force += glm::vec3(0.0f, -(*gravity), 0.0f);
}

void Particle::Integrate(float deltaTime)
{
	
	ApplyGravity();
	

	glm::vec3 accel = (1 / *mass) * force;
	if (accel.length() > epsilon)
	{
		velocity += accel * deltaTime;
		if (velocity.length() < epsilon) velocity = glm::vec3(0.0f);
		position += velocity * deltaTime;
		//prevForce = force;
	}
	GroundCollision();


	force = glm::vec3(0.0f);
}

//void Particle::ResetForce()
//{
//	force = glm::vec3(0.0f);
//}


//void Particle::ResetNormal()
//{
//	*normal = glm::vec3(0.0f);
//}

//void Particle::AddNormal(glm::vec3 n)
//{
///	*normal += n; /*/ (float)numOfTriangles;*/
//}

void Particle::GroundCollision()
{
	float groundPos = groundTop->y + (*radius);
	if (position.x >= groundTop->x && position.x <= groundBot->x
		&& position.z >= groundTop->z && position.z <= groundBot->z
		&& position.y <= groundPos)
	{
		float v_y = velocity.y;
		if (v_y < epsilon)
		{
			position.y = groundPos + epsilon;
		}
		else
		{
			position.y = 2.0f * groundPos - position.y + epsilon;
		}
		velocity.y = 0.0f;
		float v_tan = glm::length(velocity);
		if (v_tan > epsilon)
		{
			velocity /= v_tan;
			float j = abs((1 + (*collisionElasticity)) * v_y);
			v_tan -= (*collisionFriction) * j;
			if (v_tan < 0.0f) v_tan = 0.0f;
			velocity *= v_tan;
			velocity.y = abs(v_y) * (*collisionElasticity);
		}
		else
		{
			velocity.y = abs(v_y) * (*collisionElasticity);
		}
	}
}