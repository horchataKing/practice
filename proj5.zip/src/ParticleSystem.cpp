#include "ParticleSystem.h"

ParticleSystem::ParticleSystem(GLuint ID, glm::vec3 groundTop, glm::vec3 groundBot)
{
	
	//ground = new Ground(groundCenter, groundSize, groundID);

	// Initialize the parameters for each particle	
	mass = 0.01f;
	gravity = 9.8f;
	airDensity = 1.225f; // Fluid density of air
	dragCoeff = 0.1f; // not too streamlined
	radius = 0.05f;
	collisionElasticity = 0.8f;
	collisionFriction = 0.01f;
	windSpeed = glm::vec3(0.0f);

	creationRate = 30;

	model = glm::scale(glm::vec3(radius));

	initialPos = glm::vec3(0.0f, 5.0f, 0.0f);
	initialPosVar = glm::vec3(0.1f, 0.1f, 0.1f);
	initialVelocity = glm::vec3(0.0f, 0.0f, 0.0f);
	initialVelocityVar = glm::vec3(1.0f, 1.0f, 1.0f);
	initialLifeSpan = 10.0f;
	initialLifeSpanVar = 0.0f;

	this->groundTop = groundTop;
	this->groundBot = groundBot;

	programID = ID;
	// Setting the different vertex points for the 4 points
	g_vertex_buffer_data[0] = -0.5f;
	g_vertex_buffer_data[1] = -0.5f;
	g_vertex_buffer_data[2] = 0.0f;
	g_vertex_buffer_data[3] = 0.5f;
	g_vertex_buffer_data[4] = -0.5f;
	g_vertex_buffer_data[5] = 0.0f;
	g_vertex_buffer_data[6] = -0.5f;
	g_vertex_buffer_data[7] = 0.5f;
	g_vertex_buffer_data[8] = 0.0f;
	g_vertex_buffer_data[9] = 0.5f;
	g_vertex_buffer_data[10] = 0.5f;
	g_vertex_buffer_data[11] = 0.0f;

	//particles.resize(maxParticles);
	positions.resize(maxParticles);
	colors.resize(maxParticles);

	//for (Particle* p : particles)
	for (int i = 0; i < maxParticles; i++)
	{
		Particle* p = new Particle(&mass, &radius, &gravity,
			&airDensity, &dragCoeff, &windSpeed,
			&collisionElasticity, &collisionFriction,
			&groundTop, &groundBot, initialLifeSpan);
		particles.push_back(p);
	}


	// Load the gl program and assign buffers, then instance
	LoadInstance();


	prevT = clock();
	srand((unsigned)prevT);
}

ParticleSystem::~ParticleSystem()
{
}

void ParticleSystem::LoadInstance()
{
	glUseProgram(programID);

	// First, load vbo containing the 4 vertices of particles
	glGenBuffers(1, &VBOS[0]);
	glBindBuffer(GL_ARRAY_BUFFER, VBOS[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_vertex_buffer_data), g_vertex_buffer_data, GL_STATIC_DRAW);

	glEnableVertexAttribArray(0);
	glVertexAttribPointer(
		0, // attribute. No particular reason for 0, but must match the layout in the shader.
		3, // size
		GL_FLOAT, // type
		GL_FALSE, // normalized?
		0, // stride
		(void*)0 // array buffer offset
	);

	
	// The VBO containing the positions of the particles
	glGenBuffers(1, &VBOS[1]);
	glBindBuffer(GL_ARRAY_BUFFER, VBOS[1]);
	// Initialize with empty (NULL) buffer : it will be updated later, each frame.
	glBufferData(GL_ARRAY_BUFFER, maxParticles * sizeof(glm::vec3), nullptr, GL_STREAM_DRAW);

	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, VBOS[1]);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (void*)0 );

	// The VBO containing the colors of the particles
	glGenBuffers(1, &VBOS[2]);
	glBindBuffer(GL_ARRAY_BUFFER, VBOS[2]);
	// Initialize with empty (NULL) buffer : it will be updated later, each frame.
	glBufferData(GL_ARRAY_BUFFER, maxParticles * sizeof(glm::vec3), nullptr, GL_STREAM_DRAW);
	
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (void*)0);

	// unsure
	// Unbind from the VBO.
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	// Unbind from the VAO.
	glBindVertexArray(0);

	glUseProgram(0);
	/*
	///////////////////////////////////
	// Bind to the VAO.
	glBindVertexArray(vao);

	// 1st VBO, sphere points
	//a. Bind buffer to VAO
	glBindBuffer(GL_ARRAY_BUFFER, vbos[0]);
	//b. Pass in the position data.
	glBufferData(GL_ARRAY_BUFFER,
		sizeof(glm::vec3) * spherePoints.size(),
		spherePoints.data(),
		GL_STATIC_DRAW);
	// c. Enable vertex attribute 0. Creat channel
	// We will be able to access vertices through it.
	glEnableVertexAttribArray(0);
	//d. How to read VBO
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);

	//2nd VBO, sphere normals
	//a. Bind buffer to VAO
	glBindBuffer(GL_ARRAY_BUFFER, vbos[1]);
	//b. Pass in the data.
	glBufferData(GL_ARRAY_BUFFER,
		sizeof(glm::vec3) * sphereNormals.size(),
		sphereNormals.data(),
		GL_STATIC_DRAW);
	// c. Enable vertex attribute 1. Creat channel
	// We will be able to access vertices through it.
	glEnableVertexAttribArray(1);
	//d. How to read VBO
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);

	//3nd VBO, particle positions
	//a. Bind buffer to VAO
	glBindBuffer(GL_ARRAY_BUFFER, vbos[2]);
	//b. Pass in the data.
	glBufferData(GL_ARRAY_BUFFER,
		sizeof(glm::vec3) * maxParticles,
		nullptr,
		GL_STREAM_DRAW);
	// c. Enable vertex attribute 2. Creat channel
	// We will be able to access vertices through it.
	glEnableVertexAttribArray(2);
	//d. How to read VBO
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);

	//4nd VBO, particle colors
	//a. Bind buffer to VAO
	glBindBuffer(GL_ARRAY_BUFFER, vbos[3]);
	//b. Pass in the data.
	glBufferData(GL_ARRAY_BUFFER,
		sizeof(glm::vec3) * maxParticles,
		nullptr,
		GL_STREAM_DRAW);
	// c. Enable vertex attribute 3. Creat channel
	// We will be able to access vertices through it.
	glEnableVertexAttribArray(3);
	//d. How to read VBO
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), 0);

	//vertex index
	//a. Bind to the EBO. We will use it to store the indices.
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	//b. Pass in the data.
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,
		sizeof(glm::ivec3) * sphereFaces.size(),
		sphereFaces.data(),
		GL_STATIC_DRAW);

	// Unbind from the VBO.
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	// Unbind from the VAO.
	glBindVertexArray(0);

	glUseProgram(0);
	*/
}

void ParticleSystem::Update()
{
	clock_t currT = clock();
	float deltaT = (currT - prevT) / 1000.0f;
	prevT = currT;
	creationInterval += deltaT;
	int newParticleNum = creationInterval * creationRate;
	creationInterval -= newParticleNum / creationRate;

	particleCount = 0;
	deltaT /= (float)overSample;
	for (int i = 0; i < maxParticles; i++)
	{
		if (particles[i]->isAlive)
		{
			for (int j = 0; j < overSample; j++)
			{
				particles[i]->Update(deltaT);
			}
			positions[particleCount] = particles[i]->position;
			colors[particleCount] = particles[i]->color;
			particleCount++;
		}
	}

	for (int i = 0; i < newParticleNum && particleCount < maxParticles; i++)
	{
		// Bring this particle to life, starting at initial values
		int currParticleIdx = FindIdleParticle();
		if (currParticleIdx == -1) break;
		particles[currParticleIdx]->position = glm::vec3(
				sqrt(initialPosVar.x) * randNormal(randEng) + initialPos.x,
				sqrt(initialPosVar.y) * randNormal(randEng) + initialPos.y,
				sqrt(initialPosVar.z) * randNormal(randEng) + initialPos.z);
		particles[currParticleIdx]->velocity =
			glm::vec3(
				sqrt(initialVelocityVar.x) * randNormal(randEng) + initialVelocity.x,
				sqrt(initialVelocityVar.y) * randNormal(randEng) + initialVelocity.y,
				sqrt(initialVelocityVar.z) * randNormal(randEng) + initialVelocity.z);

		particles[currParticleIdx]->lifeSpan = (sqrt(initialLifeSpanVar) *
							randNormal(randEng) + initialLifeSpan);

		particles[currParticleIdx]->color = glm::vec3(
			rand() / (float)RAND_MAX * 0.5f + 0.5f,
			rand() / (float)RAND_MAX * 0.5f + 0.5f,
			rand() / (float)RAND_MAX * 0.5f + 0.5f);

		particles[currParticleIdx]->isAlive = true;

		positions[particleCount] = particles[currParticleIdx]->position;
		colors[particleCount] = particles[currParticleIdx]->color;
		particleCount++;
	}

	//transfer to vbo
	glUseProgram(programID);

	glBindBuffer(GL_ARRAY_BUFFER, VBOS[1]);
	void* ptr = glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY);
	memcpy(ptr, positions.data(), sizeof(glm::vec3) * particleCount);
	glUnmapBuffer(GL_ARRAY_BUFFER);

	glBindBuffer(GL_ARRAY_BUFFER, VBOS[2]);
	ptr = glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY);
	memcpy(ptr, colors.data(), sizeof(glm::vec3) * particleCount);
	glUnmapBuffer(GL_ARRAY_BUFFER);

	glUseProgram(0);
}

void ParticleSystem::Draw(const glm::mat4& viewProjMtx)
{
	glUseProgram(programID);

	// get the locations and send the uniforms to the shader 
	glUniformMatrix4fv(glGetUniformLocation(programID, "viewProj"), 1, GL_FALSE, (float*)&viewProjMtx);
	glUniformMatrix4fv(glGetUniformLocation(programID, "model"), 1, GL_FALSE, (float*)&model);

	// Bind to the VAO.
	//glBindVertexArray(vao);

	

	// 3rd attribute buffer : particles' colors
	

	glVertexAttribDivisor(0, 0); // vertices : always reuse the same 4 vertices -> 0
	glVertexAttribDivisor(1, 1); // particle center
	glVertexAttribDivisor(2, 1); // particle color

	// draw the points using triangles, indexed with the EBO
	//glDrawElements(GL_TRIANGLES, sphereFaces.size() * 3, GL_UNSIGNED_INT, 0); // mode, count, type, indices
	//glDrawElementsInstanced(GL_TRIANGLES, sphereFaces.size() * 3, GL_UNSIGNED_INT, 0, particleID);
	glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, particleCount);
	// Unbind from the VAO and shader program.
	glBindVertexArray(0);
	glUseProgram(0);

	//ground->Draw(viewProjMtx);
}

int ParticleSystem::FindIdleParticle()
{

	for (int i = lastIdx; i < maxParticles; i++)
	{
		if (!particles[i]->isAlive)
		{
			lastIdx++;
			return i;
		}
	}

	for (int i = 0; i < lastIdx; i++)
	{
		if (!particles[i]->isAlive)
		{
			lastIdx++;
			return i;
		}
	}

	return 0;
}
